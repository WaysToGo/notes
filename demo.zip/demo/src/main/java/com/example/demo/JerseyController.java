package com.example.demo;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


import org.springframework.stereotype.Component;



@Component
@Path("/tasks")
public class JerseyController {
	

	
	
	Service service=new Service() ;
	
	

	  @GET
	    @Produces("application/json")
	    public Tasks getAllTasks() {
		  Tasks t1=service.init();
		  	
	        return t1;
	    }
	  
	  
	/*@Autowired
	TodoListRepo todoListRepo;
	
	  @GET
	    @Produces("application/json")
	    public List<Tasks> getAllTasks() {
		  	
	        return todoListRepo.findAll();
	    }
	  @POST
	  @Consumes("application/json")
	  @Produces("application/json")
	    public List<Tasks> saveAllTasks(Tasks tasks){
		  tasks.status="pending";
		  todoListRepo.save(tasks);
		  return todoListRepo.findAll();
		  
	  }
	  
	  
	  @GET
	  @Path("/{name}")
	    @Produces("application/json")
	    public Tasks getTask(@PathParam("name") String name) {
		  	
	        return todoListRepo.findOne(name);
	    }
	  
	  
	  @PUT
	  @Path("/{name}")
	  @Consumes("application/json")
	  @Produces("application/json")
	  public List<Tasks> saveTask(@PathParam("name") String name){
		  
			 Tasks task= todoListRepo.getOne(name);
			 task.status="pending";
			 todoListRepo.save(task);
			  
		  
		  return todoListRepo.findAll();
		  
	  }
	  
	  
	  @DELETE
	  @Path("/{name}")
	  public Response deleteTasks(@PathParam("name") String name){		  
		  todoListRepo.delete(name);
		  
		 return Response.ok().build();
		  
	  }
	  
*/
	
	
	

}
