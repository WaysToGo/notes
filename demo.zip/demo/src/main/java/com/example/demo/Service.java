package com.example.demo;

import java.util.Date;

public class Service {

	Tasks t1=new Tasks();
	public Tasks init() {
		t1.setName("shi");
		t1.setStatus("pending");
		t1.setCreated_date(new Date());
		return t1;
	}
	
	
}
